# Interrupt Request Generator

This IP can be used to generate interrupt request with a programable period.
It provides a method to evaluate the time it takes for the operating system
to handle an interrupt request, and it can also be used to determine the
maximum rate at which the interrupts can be handled by the system.

## Register map

Please see the [SystemRDL description](hdl/custom_irq_gen.rdl) of the registers.

## Example on a Zynq MPSoC

### Test setup

The IP is connected to the `pl_ps_irq0` port on the Zynq MPSoC module, it is
clocked at 100 MHz. The design runs on
[DAMC-FMC2ZUP](https://techlab.desy.de/products/amc/damc_fmc2zup/) with
XCZU11EG-L2FFVC1760E device.

![Test setup](docs/setup.png)

### Interrupt handling

A small program (written in C) is provided together with the IP to handle the
interrupts. The program checks the expected sequence number against the received
sequence number in order to detect missing interrupts. At the end, the
interrupt flag is cleared and UIO interface is re-armed for another interrupt.

In the figure below we see the interrupt handling routine from the FPGA side. At
cca 5890 clock cycle mark the interrupt is raised - the line towards the Zynq
MPSoC is asserted. At cca 6880 clock cycle mark we see the read request - this
is the software reading the sequence number. Finally, just before 7000 clock
cycle mark we see a write on the AXI bus, which clears the interrupt flag.

![Interrupt handling routine from the FPGA side](docs/handler_latency.png)

Same plot, but zooomed in on the last part of the plot - where accesses on
AXI bus happen:

![Interrupt handling routine from the FPGA side - zoomed in](docs/handler_latency_zoom.png)


### Performance - missed interrupts

When generating the interrupts at 50 kHz (= 100 MHz / 2000), we missed 16
interrupts in at least 553813 interrupt requests; a good result considering that
our interrupt handler runs in user space. Better performance can be achieved
by handling the interrupt in kernel space.

```
root@damc-fmc2zup:~# time taskset -c 3 ./irq_handler /dev/uio5 2000
check_id_version: ID register matches
period = 0x7d0
cleared irq state
seq nr mismatch (exp = 54, recv = 55)
seq nr mismatch (exp = d19a, recv = d19d)
seq nr mismatch (exp = d19f, recv = d1a0)
seq nr mismatch (exp = 1ad06, recv = 1ad07)
seq nr mismatch (exp = 1ad09, recv = 1ad0a)
seq nr mismatch (exp = 25997, recv = 2599e)
seq nr mismatch (exp = 259a0, recv = 259a1)
seq nr mismatch (exp = 3de76, recv = 3de79)
seq nr mismatch (exp = 3de7b, recv = 3de7c)
seq nr mismatch (exp = 56673, recv = 56679)
seq nr mismatch (exp = 5667b, recv = 5667c)
seq nr mismatch (exp = 57de0, recv = 57de2)
seq nr mismatch (exp = 57de4, recv = 57de5)
seq nr mismatch (exp = 6eb52, recv = 6eb55)
seq nr mismatch (exp = 6eb57, recv = 6eb58)
seq nr mismatch (exp = 8734f, recv = 87355)
```

CPU consumption when handling the interrupts at 50 kHz:

![CPU consumption](docs/cpu_consumption.png)

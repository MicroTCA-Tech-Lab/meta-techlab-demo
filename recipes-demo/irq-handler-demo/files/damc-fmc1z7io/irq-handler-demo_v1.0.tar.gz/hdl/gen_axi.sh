
hectare --axi-vhdl custom_irq_gen_axi.vhd custom_irq_gen.rdl
hectare --c-header ../software/custom_irq_gen_regs.h custom_irq_gen.rdl
